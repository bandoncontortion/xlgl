#ifndef __XLGL_ANDROID__H__
#define __XLGL_ANDROID__H__
#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

void xlglAndroidSetupSavedState(XLGLWindow* window);

#ifdef __cplusplus
}
#endif /* __cplusplus */
#endif /* __XLGL_ANDROID__H__ */
